from http.server import BaseHTTPRequestHandler, HTTPServer
import socket
import psutil

class HelloHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        hostname = socket.gethostname()
        ip_address = socket.gethostbyname(hostname)

        # Coleta de uso de CPU e memória
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        memory_used = round(memory.used / (1024 ** 2), 2)  # em MB
        memory_total = round(memory.total / (1024 ** 2), 2)  # em MB

        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()

        html = f"""
        <html>
            <body>
                <h1>Hello World</h1>
                <p><strong>Hostname:</strong> {hostname}</p>
                <p><strong>IP Address:</strong> {ip_address}</p>
                <p><strong>CPU Usage:</strong> {cpu_percent}%</p>
                <p><strong>Memory Usage:</strong> {memory_percent}% ({memory_used} MB / {memory_total} MB)</p>
            </body>
        </html>
        """
        self.wfile.write(html.encode("utf-8"))

if __name__ == "__main__":
    server_address = ("", 8080)
    httpd = HTTPServer(server_address, HelloHandler)
    print("Servidor rodando na porta 8080...")
    httpd.serve_forever()
